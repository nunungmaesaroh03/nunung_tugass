<?php


class Materi_model extends CI_Model
{
    
    public function count($by)
    {
        switch ($by) {
            case 'unread-laporan':
                $field_id       = 'laporkan-komentar';
                $retrieve_field = retrieve_field($field_id);
                if (isset($retrieve_field['value'])) {
                    $field_value = json_decode($retrieve_field['value'], 1);
                } else {
                    $field_value = array();
                }

                $unread = 0;
                foreach ($field_value as $val) {
                    if (empty($val['view_admin'])) {
                        $unread++;
                    }
                }

                return $unread;
            break;
        }
    }

   
    public function plus_views($materi_id)
    {
        $retrieve = $this->retrieve($materi_id);
        if (!empty($retrieve)) {
            $this->db->update('materi', array('views' => $retrieve['views'] + 1), array('id' => $retrieve['id']));
        }

        return true;
    }

   
    public function delete_kelas($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('materi_kelas');
        return true;
    }

  
    public function retrieve_kelas(
        $id        = null,
        $materi_id = null,
        $kelas_id  = null
    ) {
        if ($id == null && $materi_id == null && $kelas_id == null) {
            return array();
        }

        if (!is_null($id)) {
            $this->db->where('id', $id);
        }
        if (!is_null($materi_id)) {
            $this->db->where('materi_id', $materi_id);
        }
        if (!is_null($kelas_id)) {
            $this->db->where('kelas_id', $kelas_id);
        }
        $result = $this->db->get('materi_kelas', 1);
        return $result->row_array();
    }

    public function retrieve_all_kelas($materi_id)
    {
        $this->db->where('materi_id', $materi_id);
        $result = $this->db->get('materi_kelas');
        return $result->result_array();
    }

  
    public function create_kelas(
        $materi_id,
        $kelas_id
    ) {
        $materi_id = (int)$materi_id;
        $kelas_id  = (int)$kelas_id;

        $this->db->insert('materi_kelas', array(
            'materi_id' => $materi_id,
            'kelas_id'  => $kelas_id
        ));
        return $this->db->insert_id();
    }

    public function delete($id)
    {
        $id = (int)$id;

        $this->db->where('id', $id);
        $this->db->delete('materi');
        return true;
    }

 
    public function retrieve_all(
        $no_of_records = 10,
        $page_no       = 1,
        $pengajar_id   = array(),
        $siswa_id      = array(),
        $mapel_id      = array(),
        $judul         = null,
        $konten        = null,
        $tgl_posting   = null,
        $publish       = null,
        $kelas_id      = array(),
        $type          = array(),
        $pagination    = true
    ) {
        $no_of_records = (int)$no_of_records;
        $page_no       = (int)$page_no;

        $where    = array();
        $group_by = array();
        if (!empty($pengajar_id)) {
            $where['materi.pengajar_id'] = array($pengajar_id, 'where_in');
        }
        if (!empty($siswa_id)) {
            if (!empty($pengajar_id)) {
                $operation = 'or_where_in';
            } else {
                $operation = 'where_in';
            }
            $where['materi.siswa_id'] = array($siswa_id, $operation);
        }
        if (!empty($mapel_id)) {
            $where['materi.mapel_id'] = array($mapel_id, 'where_in');
        }
        $like = 0;
        if (!empty($judul)) {
            $where['materi.judul'] = array($judul, 'like');
            $like = 1;
        }
        if (!empty($konten)) {
            if ($like) {
                $value = array($like, 'or_like');
            } else {
                $value = array($like, 'like');
            }
            $where['materi.konten'] = array($like, 'like');
        }
        if (!empty($tgl_posting)) {
            $where['DATE(tgl_posting)'] = array($tgl_posting, 'where');
        }
        if (!empty($publish)) {
            $where['materi.publish'] = array($publish, 'where_in');
        }
        if (!empty($kelas_id)) {
            $where['materi_kelas']          = array('materi.id = materi_kelas.materi_id', 'join', 'inner');
            $where['materi_kelas.kelas_id'] = array($kelas_id, 'where_in');
            $group_by[] = 'materi.id';
        }
        if (!empty($type)) {
            if (count($type) == 1) {
                if ($type[0] == 'tertulis') {
                    $where['materi.konten !='] = array("", 'where');
                } elseif ($type[0] == 'file') {
                    $where['materi.file !='] = array("", 'where');
                }
            }
        }

        # cari yang mapelnya berstatus aktif yang ditampilkan
        $where['mapel'] = array('materi.mapel_id = mapel.id', 'join', 'inner');
        $where['mapel.aktif'] = array(1, 'where');

        $orderby = array(
            'materi.id' => 'DESC'
        );

        if ($pagination) {
            $data = $this->pager->set('materi', $no_of_records, $page_no, $where, $orderby, 'materi.*', $group_by);
        } else {
            # cari jumlah semua pengajar
            $no_of_records = $this->db->count_all('materi');
            $search_all    = $this->pager->set('materi', $no_of_records, $page_no, $where, $orderby, 'materi.*', $group_by);
            $data          = $search_all['results'];
        }

        return $data;
    }

  
    public function retrieve($id)
    {
        $id = (int)$id;

        $this->db->where('id', $id);
        $result = $this->db->get('materi', 1);
        return $result->row_array();
    }


    public function update(
        $id,
        $pengajar_id = null,
        $siswa_id    = null,
        $mapel_id,
        $judul,
        $konten  = null,
        $file    = null,
        $publish = 1
    ) {
        $id             = (int)$id;
        $mapel_id = (int)$mapel_id;
        $publish        = (int)$publish;

        $data = array(
            'pengajar_id' => $pengajar_id,
            'siswa_id'    => $siswa_id,
            'mapel_id'    => $mapel_id,
            'judul'       => $judul,
            'konten'      => $konten,
            'file'        => $file,
            'tgl_posting' => date('Y-m-d H:i:s'),
            'publish'     => $publish
        );
        $this->db->where('id', $id);
        $this->db->update('materi', $data);
        return true;
    }


    public function create(
        $pengajar_id = null,
        $siswa_id    = null,
        $mapel_id,
        $judul,
        $konten  = null,
        $file    = null,
        $publish = 1
    ) {
        $mapel_id = (int)$mapel_id;
        $publish        = (int)$publish;

        $data = array(
            'pengajar_id' => $pengajar_id,
            'siswa_id'    => $siswa_id,
            'mapel_id'    => $mapel_id,
            'judul'       => $judul,
            'konten'      => $konten,
            'file'        => $file,
            'tgl_posting' => date('Y-m-d H:i:s'),
            'publish'     => $publish
        );
        $this->db->insert('materi', $data);
        return $this->db->insert_id();
    }

}
