<?php


class Komentar_model extends CI_Model
{
    private $table = 'komentar';

    function __construct()
    {
        if (!$this->db->table_exists($this->table)) {
            $this->create_table();
        }
    }

   
    public function count_by($entitas, $entitas_id)
    {
        $this->db->where('tampil', 1);
        switch ($entitas) {
            case 'materi':
                $this->db->where('materi_id', $entitas_id);
            break;
        }
        $result = $this->db->get($this->table);
        return $result->num_rows();
    }

    public function delete_by_materi($materi_id)
    {
        $this->db->where('materi_id', $materi_id);
        $this->db->delete($this->table);
        return true;
    }

   
    public function delete($id)
    {
        $this->db->where('id', $id);
        $this->db->delete($this->table);
        return true;
    }

 
    public function retrieve_all(
        $no_of_records = "10",
        $page_no       = 1,
        $login_id      = null,
        $materi_id     = null,
        $tampil        = null
    ) {
        $show_record = $no_of_records;
        if ($no_of_records == "all") {
            $show_record = $this->db->count_all($this->table);
        }

        $where = array();
        if (!is_null($login_id)) {
            $where['login_id'] = array($login_id, 'where');
        }
        if (!is_null($materi_id)) {
            $where['materi_id'] = array($materi_id, 'where');
        }
        if (!is_null($tampil)) {
            $where['tampil'] = array($tampil, 'where');
        }

        $orderby = array('id' => 'DESC');
        $data = $this->pager->set($this->table, $show_record, $page_no, $where, $orderby);

        if ($no_of_records == "all") {
            return $data['results'];
        } else {
            return $data;
        }
    }

   
    public function retrieve($id)
    {
        $this->db->where('id', $id);
        $result = $this->db->get($this->table, 1);
        return $result->row_array();
    }

    public function hidden($id)
    {
        $this->db->where('id', $id);
        $this->db->update($this->table, array('tampil' => 0));
        return true;
    }


    public function create(
        $login_id,
        $materi_id,
        $tampil = 1,
        $konten = ''
    ) {
        $this->db->insert($this->table, array(
            'login_id'    => $login_id,
            'materi_id'   => $materi_id,
            'tampil'      => $tampil,
            'konten'      => $konten,
            'tgl_posting' => date('Y-m-d H:i:s')
        ));

        return $this->db->insert_id();
    }


   
    public function create_table()
    {
        $CI =& get_instance();
        $CI->load->model('config_model');

        $CI->config_model->create_tb_komentar();

        return true;
    }
}
